﻿namespace LibraryCore
{
    public class Class1
    {

    }
}
