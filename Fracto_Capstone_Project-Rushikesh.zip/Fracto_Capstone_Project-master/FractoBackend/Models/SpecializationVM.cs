using System;
using System.Collections.Generic;

namespace FractoBackend.Models;
public partial class SpecializationVM
{
    // public int SpecializationId { get; set; }

    public string SpecializationName { get; set; } = null!;
}