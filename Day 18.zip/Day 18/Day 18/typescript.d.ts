export {};
//# sourceMappingURL=typescript.d.ts.map