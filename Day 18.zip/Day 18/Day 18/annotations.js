var alice = {
    name: 'Alice',
    employeeId: 5678
};
console.log("Employee: ".concat(alice.name, ", ID: ").concat(alice.employeeId));
// Output: Employee: Alice, ID: 5678
