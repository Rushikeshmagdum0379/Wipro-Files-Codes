var alice1 = {
    name: 'Alice2',
    age: 30
};
console.log("User: ".concat(alice1.name, ", Age: ").concat(alice1.age)); // Output: User: Alice, Age: 30
