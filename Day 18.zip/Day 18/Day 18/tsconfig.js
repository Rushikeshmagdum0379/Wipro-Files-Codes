{
    "compilerOptions": {
      "target": "es2015",
      "lib": ["es2015", "dom"],
      "module": "commonjs",
      "strict": true
    }
  }
  