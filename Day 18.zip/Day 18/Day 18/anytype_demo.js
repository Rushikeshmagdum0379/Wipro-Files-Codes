var data = 42;
data = "Now I'm a string!";
data = { key: 'value' };
data = [1, 2, 3, 4, 5];
console.log(data); // Output: { key: 'value' }
data = { name: 'Alice', age: 30 };
console.log(data); // Output: { name: 'Alice', age: 30 }
